#include <iostream>

#include "module_a.h"

int main(int argc, char *argv[])
{
    std::cout << cpp_type_name<int&>() << '\n';
    return 0;
}
