//
// Created by Konstantin Gredeskoul on 5/16/17.
//
#include "gtest/gtest.h"

#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <numeric>
#include <iostream>
#include <cmath>
#include <string>

#include "module_a/module_a.h"

class CppTypeNameTest : public ::testing::Test {
protected:
    std::string result = "int &";
};

TEST_F(CppTypeNameTest, MyTest) {
    EXPECT_EQ(1, 1);
    EXPECT_STREQ(cpp_type_name<int&>().c_str(), result.c_str());
}
