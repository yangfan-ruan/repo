# find_package(matplot REQUIRED)
if(CMAKE_GENERATOR MATCHES "Visual Studio")
    message("Visual Studio is not supported.")
else()
    # message("Non-Visual Studio generator detected.")
if(CMAKE_SYSTEM_NAME MATCHES "Windows")
    message("Windows is not supported.")
else()
    set(MATPLOT_LIB_PATH
        /usr/lib
    )

# 包含目录
    set(MATPLOT_INCLUDE_PATH
        /usr/include/matplot
    )

    file(GLOB MATPLOT_LIBS ${MATPLOT_LIB_PATH}/libmatplot.so)

endif() # CMAKE_SYSTEM_NAME
endif() # CMAKE_GENERATOR

add_library(matplot INTERFACE)
target_link_libraries(matplot INTERFACE ${MATPLOT_LIBS})
target_include_directories(matplot INTERFACE ${MATPLOT_INCLUDE_PATH})
target_link_directories(matplot INTERFACE ${MATPLOT_LIB_PATH})

