# remember to check path, and environment variables
# libs of different version cannot be linked at the same time
# eg: debug/release, static/shared

if(CMAKE_SYSTEM_NAME MATCHES "Windows") 
if(CMAKE_GENERATOR MATCHES "Visual Studio")
    message("Visual Studio generator detected.")
    # Visual Studio 特定的配置(path on monica)
    set(OPENCV_PATH 
        C:/MySoft/opencv4.5.5/build_vc
    )
    
    set(OPENCV_LIB_PATH
        ${OPENCV_PATH}/x64/vc15/lib
    )
    set(OPENCV_INCLUDE_PATH
        ${OPENCV_PATH}/include
    )
    file(GLOB OPENCV_LIBS ${OPENCV_LIB_PATH}/*d.lib) # opencv world d.lib

else() # mingw: min G W
    message("Non-Visual Studio generator detected.")

    set(OPENCV_PATH 
        C:/MySoft/opencv4.5.5/build_mingw/install
    )

    set(OPENCV_LIB_PATH
        ${OPENCV_PATH}/x64/mingw/lib
    )
    set(OPENCV_INCLUDE_PATH
        ${OPENCV_PATH}/include
    )
    file(GLOB OPENCV_LIBS ${OPENCV_LIB_PATH}/lib*)

endif() # CMAKE_GENERATOR
else() # linux

    # set(OPENCV_PATH path/to/opencv)
    set(OPENCV_LIB_PATH
        /usr/lib
    )
    set(OPENCV_INCLUDE_PATH
        /usr/include/opencv4
    )
    file(GLOB OPENCV_LIBS ${OPENCV_LIB_PATH}/libopencv*)

endif() # CMAKE_SYSTEM_NAME

add_library(opencv INTERFACE)
target_link_libraries(opencv INTERFACE ${OPENCV_LIBS})
target_include_directories(opencv INTERFACE ${OPENCV_INCLUDE_PATH})
target_link_directories(opencv INTERFACE ${OPENCV_LIB_PATH})

# message("generator: ${CMAKE_GENERATOR}")
# message("OPENCV_PATH: ${OPENCV_PATH}")
# message("OPENCV_LIB_PATH: ${OPENCV_LIB_PATH}")
# message("OPENCV_LIBS: ${OPENCV_LIBS}")
