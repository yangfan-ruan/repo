#include "module_a/module_a.h"
#include <iostream>

void printHello(void) {
    std::cout << "hello" << std::endl;
}

