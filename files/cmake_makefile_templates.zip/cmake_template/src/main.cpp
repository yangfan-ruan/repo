#include <iostream>

#include "module_a/module_a.h"

int main(int argc, char *argv[]) {
    std::cout << "hello" << std::endl;
    return 0;
}
